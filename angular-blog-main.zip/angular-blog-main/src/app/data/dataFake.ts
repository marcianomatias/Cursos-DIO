export const dataFake = [
  {
    id: '1',
    title: 'Hulk',
    description:
      'The Incredible Hulk (Br/Prt: O Incrível Hulk) é um filme americano de super-herói de 2008 baseado no personagem Hulk da Marvel Comics, produzido pela Marvel ...',
    photoCover:
      'https://observatoriodocinema.uol.com.br/wp-content/uploads/2022/08/O-Incrivel-Hulk-Divulgacao-1200x900-1.jpg',
  },
  {
    id: '2',
    title: 'Mulher-Hulk',
    description:
      'Mulher-Hulk é uma personagem fictícia que aparece nos quadrinhos americanos publicados pela Marvel Comics, criada pelo roteirista Stan Lee e pelo desenhista John Buscema em Savage She-Hulk #1',
    photoCover:
      'https://recreio.uol.com.br/media/uploads/marvel/she-hulk_capa.jpg',
  },
  {
    id: '3',
    title: 'homem de ferro',
    description:
      'O Homem de Ferro foi um personagem dos quadrinhos publicados pela Marvel Comics. Sua verdadeira identidade é o empresário e bilionário Tony Stark, que usou armaduras de alta tecnologia no combate ao crime. Foi criado em 1963 pelo escritor Stan Lee, o roteirista Larry Lieber e os desenhistas Jack Kirby e Don Heck',
    photoCover:
      'https://observatoriodocinema.uol.com.br/wp-content/uploads/2021/02/homem-de-ferro-tony-divulgacao.jpg',
  },
  {
    id: '4',
    title: 'Marvel',
    description:
      'A Marvel Comics é uma editora norte-americana de mídias relacionadas. Hoje a Marvel Comics é considerada a maior editora de histórias em quadrinhos do mundo. Em 2009, a The Walt Disney Company, adquiriu a Marvel Entertainment, a empresa mãe da Marvel',
    photoCover:
      'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Marvel_Logo.svg/1200px-Marvel_Logo.svg.png',
  },
];
